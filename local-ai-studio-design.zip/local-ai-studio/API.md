# API 与事件协议 v0.1

统一 /api/v1，JSON camelCase，UUID字符串，UTC毫秒时间。OpenAPI作为前后端契约，生成TypeScript客户端。分页使用cursor/limit（默认30，上限100）。错误格式：{"code":"INVALID_REFERENCE","message":"资产版本不存在","details":{},"requestId":"..."}。

|Method|Path|语义|
|---|---|---|
|POST/GET|/projects|创建/列表|
|GET/PATCH|/projects/{id}|详情/更新|
|POST|/projects/{id}/outline/generate|生成大纲任务|
|POST|/projects/{id}/episodes/plan|分集规划任务|
|GET|/projects/{id}/episodes|剧集列表|
|POST|/episodes/{id}/script/generate|剧本生成任务|
|PUT|/episodes/{id}/script|创建剧本修订|
|POST|/projects/{id}/assets/extract|提取资产任务|
|GET/POST|/projects/{id}/assets|资产列表/创建|
|POST|/assets/{id}/generate|资产生成任务|
|POST|/assets/{id}/versions/{vid}/approve|审核并选定版本|
|POST|/episodes/{id}/shots/plan|拆镜任务|
|GET|/episodes/{id}/shots|镜头列表|
|PATCH|/shots/{id}|创建镜头修订|
|POST|/shots/{id}/keyframes/generate|分镜图任务|
|POST|/shots/{id}/render|视频渲染任务|
|POST|/shots/{id}/audio/generate|对白任务|
|POST|/episodes/{id}/render|批量任务计划|
|GET/PUT|/episodes/{id}/timeline|读取/保存时间轴修订|
|POST|/episodes/{id}/export|成片任务|
|GET|/tasks/{id}|任务详情及attempt|
|GET|/tasks|任务列表，按项目/状态过滤|
|POST|/tasks/{id}/retry|创建重试attempt|
|POST|/tasks/{id}/cancel|请求取消|
|GET|/events|SSE事件流|
|GET|/engines|服务状态与能力|
|GET|/workflows|可用模板与参数schema|
|GET|/system/resources|GPU/RAM/磁盘|
|GET|/media/{id}|媒体读取，支持Range|

## 示例
POST /api/v1/shots/{id}/render，Header: Idempotency-Key: <uuid>
```json
{"shotRevisionId":"rev-1","workflowId":"h3-i2v","workflowVersion":"1.0.0","references":[{"assetVersionId":"asset-v1","role":"first_frame"}],"parameters":{"durationMs":5000,"resolution":"480p","seed":12345}}
```
示例ID为占位，实际使用UUID。后端校验模板能力、版本、审批、资源限制，计算合法帧数。返回202：{"taskId":"...","status":"PENDING"}。相同幂等键与相同请求返回原任务；不同请求返回409。编辑请求带expectedRevision，冲突返回409。404不存在，422业务校验失败，503引擎不可用（或按策略等待）。

## SSE
```
id: 123
event: task.updated
data: {"taskId":"...","status":"RUNNING","stage":"SAMPLING","nodeProgress":0.75,"overallProgress":null}

```
事件序号持久化；Last-Event-ID重放，超出保留窗口发送reset事件并重新获取快照。心跳15–30秒。前端按事件序号去重。节点进度不冒充全局进度。终态以持久化任务及结果为准。

## ComfyUI内部契约
POST /prompt（API图、client_id）；WS /ws?clientId=...；GET /history/{prompt_id}；GET /queue；POST /queue或/interrupt按实际版本取消；POST /free按需卸载；GET /object_info检查模板。输出解析器按节点类型处理图片、音频、视频，不假定所有输出均为images。内部API不直接暴露前端。真实版本接口需在M0冒烟验证。
