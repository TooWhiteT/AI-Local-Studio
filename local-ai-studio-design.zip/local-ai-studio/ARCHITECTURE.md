# 技术架构 v0.1

## 运行拓扑
Vue 3 / TypeScript / Vite / Pinia / Naive UI → Ktor REST + SSE → 应用服务 → 持久化任务调度 → 引擎适配器（ComfyUI REST/WS、llama.cpp OpenAI兼容API、TTS FastAPI、FFmpeg进程）。SQLite WAL与本地文件系统为权威数据源。正式环境Ktor托管SPA；开发Vite代理/api。默认绑定127.0.0.1。端口建议8080/8188/8081/8000。

## 工程结构
```
frontend/src/{api,stores,router,features,components}
backend/{app,core,domain,application,infrastructure,engine-api,engine-comfy,engine-llm,engine-tts,engine-media,scheduler}
workflows/<id>/<version>/{workflow.json,manifest.json}
prompts/<role>/<version>.md
storage/{projects,staging,comfy-input,comfy-output}
```
依赖方向：domain不依赖框架；application依赖domain和engine-api；infrastructure实现repository；各engine实现接口；app负责装配。初期允许feature包而非每个feature独立Gradle模块。前端按业务feature组织，服务端状态由API获取，Pinia不作为持久化来源。

## 工作流注册
真实ComfyUI中测试并导出API JSON，不使用UI布局JSON。manifest定义id、version、capabilities、参数类型/范围、node/input映射、输出节点、模型依赖、资源估算。启动时通过/object_info验证节点与参数，缺失则禁用模板。模型名称和H3模式以本机验证为准，不假定此前讨论的文件名必然存在。每次任务保存模板版本、参数、输入资产版本、seed及引擎版本。禁止LLM生成任意节点图直接执行。

## 执行链路
1. API事务写入任务及依赖，返回202。
2. 调度器选择依赖成功且审核通过的READY任务；获取GPU租约。
3. 解析固定资产版本，复制到受控input目录，注入模板。
4. 建立ComfyUI WS，POST /prompt，持久化prompt_id；监听事件并用/history确认结果。
5. 校验文件、FFprobe或图像解码，原子移动到资产库，事务写入结果及事件。
6. 释放GPU租约，唤醒依赖任务。失败记录错误，不覆盖已审核产物。

## 单GPU策略
全局并发重型任务=1；同类模型批处理但保留交互任务优先级与防饥饿。租约覆盖提交、执行、结果确认及必要卸载。切换引擎前检查实际队列和NVML显存、系统可用内存；ComfyUI /free仅释放自身模型，必要时停止LLM/TTS进程。48GB RAM不允许无限CPU offload。OOM默认不无限重试，提示降低帧数、分辨率或参考数。取消请求后等待引擎真正停止才释放租约。外部手工ComfyUI任务需检测或禁止并发。默认480P、3–5秒、batch=1，实际合法帧数由模板能力决定。

## 恢复与一致性
任务状态与事件同事务写入；启动检查RUNNING/SUBMITTED及ComfyUI queue/history。提交超时且未获得prompt_id时标记UNKNOWN，人工或引擎记录核对，不盲目重试。每次重试新attempt，业务任务ID不变。SSE断线用事件游标重放或快照恢复。数据库事务不得跨GPU执行。文件先写staging再原子重命名；启动清理孤立临时文件，已入库素材不可直接覆盖。

## 安全与可观测性
路径规范化并限制在存储根目录；拒绝路径穿越、任意命令、任意节点与任意远程URL。FFmpeg使用参数数组而非shell拼接。限制上传大小与类型。记录taskId、attemptId、promptId、耗时、峰值显存/RAM、错误类别；日志不记录敏感凭据。局域网开放前增加认证、CSRF与Origin校验。

## 测试
单元：模板绑定、DAG环检测、状态机、路径校验、失效传播。集成：SQLite迁移、模拟ComfyUI REST/WS、SSE恢复、提交不确定状态。真实GPU冒烟：Z-Image一张图、H3一段短视频、TTS一句话、FFmpeg合成；记录实际峰值和耗时。模型及依赖版本在M0锁定，不凭空指定最新版本。
